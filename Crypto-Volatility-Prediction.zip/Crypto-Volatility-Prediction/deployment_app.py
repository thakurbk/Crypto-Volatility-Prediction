import streamlit as st
import xgboost as xgb
import numpy as np

st.title("Cryptocurrency Volatility Predictor")
st.markdown("PW Skills ML Assignment")

@st.cache_resource
def load_model():
    model = xgb.XGBRegressor()
    model.load_model("bitcoin_volatility_model.json")
    return model

model = load_model()

st.sidebar.header("Input Features")
price_range = st.sidebar.slider("Price Range", 0.0, 0.2, 0.05)
liq_ratio = st.sidebar.slider("Liquidity Ratio", 0.0, 0.1, 0.02)
rsi = st.sidebar.slider("RSI", 20, 80, 60)

if st.button("Predict Volatility"):
    features = np.array([price_range, liq_ratio, 0.75, rsi, 0.03, 0.04, 0.05, 0.01, 0.02])
    pred = model.predict(features.reshape(1, -1))[0]
    st.metric("Predicted Volatility", f"{pred:.4f}")
    st.success("Model deployed successfully!")
