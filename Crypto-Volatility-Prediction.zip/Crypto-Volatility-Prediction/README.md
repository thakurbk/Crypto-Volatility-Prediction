# Crypto Volatility Predictor
pip install -r requirements.txt
streamlit run deployment_app.py

Results: Bitcoin R²=0.81